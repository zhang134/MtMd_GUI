% cd-hit ������ת��Ϊ��ǩ����ȡNMIֵ
% ���룺������Clusterslist   ԭͷ�ļ�headers
function cluster=CdhitClusterMeasure(Clusterslist,headers)
header={};
% % % % Extracted the Assigned matrix from the results of cd-hit/NbHClust
fid=fopen(Clusterslist);
AssignMatrix=[];
Index=0;
n=0;
temp={};
while 1
    tline=fgetl(fid);
    if ~ischar(tline), break, end
    if ~isempty(findstr(tline,'>Cluster'))
        Index=Index+1;
        n=n+1;
        header{n}=temp;
        temp={};
        num=0;
%        AssignMatrix(Index,:)=zeros(1,TruthclusterNums); %#ok<AGROW>
    else
        Poi=findstr(tline,'.');
        if length(Poi)>=2
            Str=tline((Poi(1)+3):(Poi(2)-1));
            num=num+1;
           temp{num}=Str;
        end
    end
end
fclose(fid);
cluster=cell(1,length(header)-1);
for i=2:length(header)
    ssss=header{i};
    mm=[];
    for j=1:length(ssss)
        iss=ssss{j};
        fprintf('%d �� %d ��\n',i,j);
        for v=1:length(headers)
            if strcmp(headers{v},iss)
                mm=[mm,v];
                break;
            end
        end
    end
    cluster{i-1}=mm;
end

end

